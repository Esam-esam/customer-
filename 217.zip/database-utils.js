// Database utilities for import and export functionality using binary format (.bin)

// FileSaver.js for saveAs functionality
const fileSaverCdn = "https://cdn.jsdelivr.net/npm/file-saver@2.0.5/dist/FileSaver.min.js";

// Load FileSaver library dynamically
function loadFileSaverLibrary() {
    return new Promise((resolve, reject) => {
        if (window.saveAs) {
            resolve(window.saveAs);
            return;
        }

        const script = document.createElement('script');
        script.src = fileSaverCdn;
        script.onload = () => resolve(window.saveAs);
        script.onerror = () => reject(new Error('Failed to load FileSaver library'));
        document.head.appendChild(script);
    });
}

// Export customers data to .bin file
async function exportDatabase() {
    try {
        await loadFileSaverLibrary();
        
        // Get customers data from localStorage
        const customersData = JSON.parse(localStorage.getItem('customers')) || [];
        
        // Convert to JSON string
        const jsonString = JSON.stringify(customersData);
        
        // Convert string to binary data
        const blob = new Blob([jsonString], { type: 'application/octet-stream' });
        
        // Use saveAs to prompt download dialog
        saveAs(blob, 'قاعدة_بيانات_العملاء.bin');
        
        alert('تم تصدير البيانات بنجاح');
        return true;
    } catch (error) {
        console.error('Failed to export data:', error);
        alert('حدث خطأ أثناء تصدير البيانات: ' + error.message);
        return false;
    }
}

// Import customers data from .bin file
function importDatabase(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            try {
                // Parse the binary data as text
                const jsonString = e.target.result;
                
                // Parse the JSON
                const importedCustomers = JSON.parse(jsonString);
                
                if (!Array.isArray(importedCustomers)) {
                    throw new Error('صيغة الملف غير صالحة');
                }
                
                if (confirm(`تم العثور على ${importedCustomers.length} عميل في الملف. هل تريد استيرادهم؟`)) {
                    // Get current customers from localStorage
                    const currentCustomers = JSON.parse(localStorage.getItem('customers')) || [];
                    
                    // Ensure all imported customers have valid IDs
                    importedCustomers.forEach(customer => {
                        if (!customer.id) {
                            customer.id = Date.now().toString() + Math.random().toString(36).substr(2, 5);
                        }
                        
                        // Ensure transactions have proper IDs
                        customer.transactions.forEach(transaction => {
                            if (!transaction.id) {
                                transaction.id = Date.now().toString() + Math.random().toString(36).substr(2, 5);
                            }
                        });
                    });
                    
                    // Merge the imported customers with existing ones
                    importedCustomers.forEach(importedCustomer => {
                        const existingCustomer = currentCustomers.find(c => c.name === importedCustomer.name);
                        
                        if (existingCustomer) {
                            existingCustomer.balance = importedCustomer.balance;
                            
                            importedCustomer.transactions.forEach(transaction => {
                                const existingTransaction = existingCustomer.transactions.find(t => 
                                    t.date === transaction.date && 
                                    t.amount === transaction.amount && 
                                    t.type === transaction.type
                                );
                                
                                if (!existingTransaction) {
                                    existingCustomer.transactions.push(transaction);
                                }
                            });
                        } else {
                            currentCustomers.push(importedCustomer);
                        }
                    });
                    
                    // Save merged customers back to localStorage
                    localStorage.setItem('customers', JSON.stringify(currentCustomers));
                    
                    alert('تم استيراد البيانات بنجاح');
                    
                    // Reload the page to refresh data
                    location.reload();
                }
                
                resolve(true);
            } catch (error) {
                reject(error);
            }
        };
        
        reader.onerror = function() {
            reject(new Error('Failed to read file'));
        };
        
        // Read the file as text
        reader.readAsText(file);
    });
}

export { exportDatabase, importDatabase };