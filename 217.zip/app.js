// Import activation system
import { checkActivation, activateApp } from './activation.js';
import { exportDatabase, importDatabase } from './database-utils.js';

// بيانات التطبيق
let customers = JSON.parse(localStorage.getItem('customers')) || [];
let activationStatus;

// الدوال المساعدة
function saveCustomers() {
    localStorage.setItem('customers', JSON.stringify(customers));
}

function formatDate(date) {
    const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' };
    return new Date(date).toLocaleDateString('ar-EG', options);
}

function formatCurrency(amount) {
    // Use absolute value to remove negative sign
    const absAmount = Math.abs(Number(amount));
    return absAmount.toLocaleString('ar-EG', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

// تحديث قائمة العملاء
function updateCustomerSelect() {
    const select = document.getElementById('customerSelect');
    select.innerHTML = '<option value="">-- اختر عميل --</option>';
    
    customers.forEach(customer => {
        const option = document.createElement('option');
        option.value = customer.id;
        option.textContent = customer.name;
        select.appendChild(option);
    });
}

// عرض قائمة العملاء
function displayCustomers(customersToDisplay = customers) {
    const tableBody = document.querySelector('#customersTable tbody');
    tableBody.innerHTML = '';
    
    if (customersToDisplay.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = '<td colspan="3" style="text-align:center">لا يوجد عملاء</td>';
        tableBody.appendChild(row);
        return;
    }
    
    customersToDisplay.forEach(customer => {
        const row = document.createElement('tr');
        
        row.innerHTML = `
            <td class="customer-name clickable" data-id="${customer.id}">${customer.name}</td>
            <td class="customer-balance ${customer.balance >= 0 ? 'credit' : 'debit'}">${formatCurrency(customer.balance)}</td>
            <td class="actions-cell"></td>
        `;
        
        tableBody.appendChild(row);
    });
    
    // إضافة مستمعي الأحداث للأسماء
    document.querySelectorAll('.customer-name.clickable').forEach(name => {
        name.addEventListener('click', () => viewCustomerDetails(name.dataset.id));
    });
}

// إضافة عميل جديد
function addCustomer(name, initialBalance) {
    // التحقق من عدم تكرار اسم العميل
    if (customers.some(customer => customer.name.toLowerCase() === name.toLowerCase())) {
        alert('هذا الاسم موجود بالفعل، الرجاء اختيار اسم آخر');
        return false;
    }
    
    const newCustomer = {
        id: Date.now().toString(),
        name,
        balance: 0,
        transactions: []
    };
    
    customers.push(newCustomer);
    saveCustomers();
    updateCustomerSelect();
    displayCustomers();
    return true;
}

// إضافة معاملة
function addTransaction(customerId, type, amount, description) {
    const customer = customers.find(c => c.id === customerId);
    if (!customer) return false;
    
    const amountValue = parseFloat(amount);
    
    const transaction = {
        id: Date.now().toString(),
        date: new Date().toISOString(),
        type,
        amount: amountValue,
        description,
        balanceBefore: customer.balance,
        balanceAfter: type === 'credit' ? customer.balance + amountValue : customer.balance - amountValue
    };
    
    // تحديث الرصيد
    if (type === 'credit') {
        customer.balance += amountValue;
    } else {
        customer.balance -= amountValue;
    }
    
    customer.transactions.push(transaction);
    saveCustomers();
    displayCustomers();
    return true;
}

// عرض تفاصيل العميل
function viewCustomerDetails(customerId) {
    const customer = customers.find(c => c.id === customerId);
    if (!customer) return;
    
    document.getElementById('modalCustomerName').textContent = customer.name;
    
    const balanceElement = document.getElementById('modalCustomerBalance');
    balanceElement.textContent = formatCurrency(customer.balance);
    
    // تغيير لون الرصيد بناءً على القيمة
    if (customer.balance < 0) {
        balanceElement.className = 'debit';
    } else {
        balanceElement.className = 'credit';
    }
    
    // تخزين معرف العميل في زر الحذف وزر تحميل التقرير
    document.getElementById('deleteCustomerBtn').dataset.id = customerId;
    document.getElementById('addCustomerTransactionBtn').dataset.id = customerId;
    document.querySelector('.download-customer-report-btn').dataset.id = customerId;
    
    // إخفاء نموذج إضافة المعاملة في حالة كان مفتوحاً
    const modalTransactionForm = document.getElementById('modalTransactionForm');
    if (modalTransactionForm) {
        modalTransactionForm.style.display = 'none';
    }
    
    const tableBody = document.querySelector('#transactionsTable tbody');
    tableBody.innerHTML = '';
    
    if (customer.transactions.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = '<td colspan="4" style="text-align:center">لا يوجد معاملات</td>';
        tableBody.appendChild(row);
    } else {
        // ترتيب المعاملات من الأحدث إلى الأقدم
        const sortedTransactions = [...customer.transactions].sort((a, b) => 
            new Date(b.date) - new Date(a.date)
        );
        
        sortedTransactions.forEach(transaction => {
            const row = document.createElement('tr');
            row.className = 'transaction-row';
            row.dataset.id = transaction.id;
            row.dataset.customerId = customerId;
            row.innerHTML = `
                <td>${formatDate(transaction.date)}</td>
                <td class="${transaction.type === 'credit' ? 'credit' : 'debit'}">
                    ${transaction.type === 'credit' ? 'إضافة' : 'خصم'} ${formatCurrency(transaction.amount)}
                    ${transaction.description ? `<div class="transaction-desc">${transaction.description}</div>` : ''}
                </td>
                <td class="before-balance ${transaction.balanceBefore >= 0 ? 'credit' : 'debit'}">${formatCurrency(transaction.balanceBefore || 0)}</td>
                <td class="after-balance ${transaction.balanceAfter >= 0 ? 'credit' : 'debit'}">${formatCurrency(transaction.balanceAfter || 0)}</td>
            `;
            
            // إضافة معالج للضغط المطول
            setupLongPressHandler(row, transaction, customerId);
            
            tableBody.appendChild(row);
        });
    }
    
    document.getElementById('customerDetails').style.display = 'block';
}

// دالة إعداد الضغط المطول
function setupLongPressHandler(element, transaction, customerId) {
    let timer;
    let isLongPress = false;
    
    element.addEventListener('touchstart', (e) => {
        timer = setTimeout(() => {
            isLongPress = true;
            showTransactionActions(element, transaction, customerId);
        }, 500); // 500ms للضغط المطول
    });
    
    element.addEventListener('touchend', () => {
        clearTimeout(timer);
        isLongPress = false;
    });
    
    element.addEventListener('touchmove', () => {
        clearTimeout(timer);
        isLongPress = false;
    });
    
    // دعم للكمبيوتر (الماوس)
    element.addEventListener('mousedown', (e) => {
        timer = setTimeout(() => {
            isLongPress = true;
            showTransactionActions(element, transaction, customerId);
        }, 500);
    });
    
    element.addEventListener('mouseup', () => {
        clearTimeout(timer);
        isLongPress = false;
    });
    
    element.addEventListener('mouseleave', () => {
        clearTimeout(timer);
        isLongPress = false;
    });
}

// إظهار خيارات المعاملة (تعديل/حذف)
function showTransactionActions(element, transaction, customerId) {
    // إزالة أي أزرار إجراءات سابقة
    document.querySelectorAll('.transaction-actions').forEach(el => el.remove());
    
    // إنشاء شريط إجراءات جديد
    const actionsDiv = document.createElement('div');
    actionsDiv.className = 'transaction-actions';
    
    // زر التعديل
    const editBtn = document.createElement('button');
    editBtn.className = 'transaction-action-btn edit-transaction-btn';
    editBtn.innerHTML = 'تعديل';
    editBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        editTransaction(transaction, customerId);
    });
    
    // زر الحذف
    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'transaction-action-btn delete-transaction-btn';
    deleteBtn.innerHTML = 'حذف';
    deleteBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (confirm('هل أنت متأكد من حذف هذه المعاملة؟')) {
            deleteTransaction(transaction.id, customerId);
        }
    });
    
    // إضافة الأزرار إلى الإجراءات
    actionsDiv.appendChild(editBtn);
    actionsDiv.appendChild(deleteBtn);
    
    // إضافة الإجراءات إلى الصف
    element.appendChild(actionsDiv);
    
    // إغلاق الإجراءات عند النقر في أي مكان آخر
    document.addEventListener('click', function closeActions(e) {
        if (!element.contains(e.target)) {
            actionsDiv.remove();
            document.removeEventListener('click', closeActions);
        }
    });
}

// دالة حذف المعاملة
function deleteTransaction(transactionId, customerId) {
    const customer = customers.find(c => c.id === customerId);
    if (!customer) return;
    
    // العثور على المعاملة
    const transactionIndex = customer.transactions.findIndex(t => t.id === transactionId);
    if (transactionIndex === -1) return;
    
    const transaction = customer.transactions[transactionIndex];
    
    // عكس تأثير المعاملة على الرصيد
    if (transaction.type === 'credit') {
        customer.balance -= transaction.amount;
    } else {
        customer.balance += transaction.amount;
    }
    
    // حذف المعاملة
    customer.transactions.splice(transactionIndex, 1);
    
    // إعادة حساب الأرصدة لجميع المعاملات بعد هذه المعاملة
    recalculateBalances(customer);
    
    // حفظ التغييرات وتحديث العرض
    saveCustomers();
    viewCustomerDetails(customerId);
    displayCustomers();
}

// دالة تعديل المعاملة
function editTransaction(transaction, customerId) {
    const customer = customers.find(c => c.id === customerId);
    if (!customer) return;
    
    // إنشاء نموذج تعديل المعاملة
    let editForm = document.getElementById('editTransactionForm');
    if (editForm) {
        editForm.remove();
    }
    
    editForm = document.createElement('form');
    editForm.id = 'editTransactionForm';
    editForm.className = 'edit-transaction-form';
    
    editForm.innerHTML = `
        <div class="form-group">
            <label for="editTransactionType">نوع المعاملة:</label>
            <select id="editTransactionType" required>
                <option value="credit" ${transaction.type === 'credit' ? 'selected' : ''}>إضافة</option>
                <option value="debit" ${transaction.type === 'debit' ? 'selected' : ''}>خصم</option>
            </select>
        </div>
        <div class="form-group">
            <label for="editTransactionAmount">المبلغ:</label>
            <input type="number" id="editTransactionAmount" value="${transaction.amount}" required min="0.01" step="0.01">
        </div>
        <div class="form-group">
            <label for="editTransactionDescription">الوصف:</label>
            <input type="text" id="editTransactionDescription" value="${transaction.description || ''}">
        </div>
        <div class="form-actions">
            <button type="button" class="btn cancel-btn" id="cancelEditTransaction">إلغاء</button>
            <button type="submit" class="btn">حفظ التغييرات</button>
        </div>
    `;
    
    // إضافة النموذج قبل جدول المعاملات
    document.getElementById('transactionsTable').parentNode.insertBefore(
        editForm, 
        document.getElementById('transactionsTable')
    );
    
    // معالج إلغاء التعديل
    document.getElementById('cancelEditTransaction').addEventListener('click', function() {
        editForm.remove();
    });
    
    // معالج حفظ التعديلات
    editForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const newType = document.getElementById('editTransactionType').value;
        const newAmount = parseFloat(document.getElementById('editTransactionAmount').value);
        const newDescription = document.getElementById('editTransactionDescription').value.trim();
        
        if (newAmount <= 0) {
            alert('يجب أن يكون المبلغ أكبر من صفر');
            return;
        }
        
        // عكس تأثير المعاملة القديمة
        if (transaction.type === 'credit') {
            customer.balance -= transaction.amount;
        } else {
            customer.balance += transaction.amount;
        }
        
        // تطبيق تأثير المعاملة الجديدة
        if (newType === 'credit') {
            customer.balance += newAmount;
        } else {
            customer.balance -= newAmount;
        }
        
        // تحديث بيانات المعاملة
        transaction.type = newType;
        transaction.amount = newAmount;
        transaction.description = newDescription;
        
        // إعادة حساب الأرصدة لجميع المعاملات
        recalculateBalances(customer);
        
        // حفظ التغييرات وتحديث العرض
        saveCustomers();
        viewCustomerDetails(customerId);
        displayCustomers();
        
        // إزالة النموذج
        editForm.remove();
    });
}

// إعادة حساب أرصدة المعاملات
function recalculateBalances(customer) {
    // ترتيب المعاملات حسب التاريخ (من الأقدم للأحدث)
    const sortedTransactions = [...customer.transactions].sort((a, b) => 
        new Date(a.date) - new Date(b.date)
    );
    
    let runningBalance = 0;
    
    sortedTransactions.forEach(transaction => {
        transaction.balanceBefore = runningBalance;
        
        if (transaction.type === 'credit') {
            runningBalance += transaction.amount;
        } else {
            runningBalance -= transaction.amount;
        }
        
        transaction.balanceAfter = runningBalance;
    });
    
    // التأكد من تحديث رصيد العميل بشكل صحيح
    customer.balance = runningBalance;
}

// حذف معاملات العميل فقط
function deleteCustomerTransactions(customerId) {
    const customer = customers.find(c => c.id === customerId);
    if (!customer) return;
    
    customer.transactions = [];
    customer.balance = 0;
    
    saveCustomers();
    updateCustomerSelect();
    displayCustomers();
    
    alert('تم حذف معاملات العميل بنجاح');
}

// حذف عميل
function deleteCustomer(customerId) {
    customers = customers.filter(c => c.id !== customerId);
    
    saveCustomers();
    updateCustomerSelect();
    displayCustomers();
    
    alert('تم حذف العميل وجميع معاملاته بنجاح');
}

// Setup activation system
function setupActivationSystem() {
    const activateBtn = document.getElementById('activateAppBtn');
    const activationModal = document.getElementById('activationModal');
    const closeBtn = activationModal.querySelector('.close');
    const activationForm = document.getElementById('activationForm');
    const trialDaysRemaining = document.getElementById('trialDaysRemaining');
    const deviceIdDisplay = document.getElementById('deviceIdDisplay');
    const copyDeviceIdBtn = document.getElementById('copyDeviceIdBtn');
    
    import('./activation.js').then(({ checkActivation, getDeviceId }) => {
        activationStatus = checkActivation();
        
        const deviceId = getDeviceId();
        deviceIdDisplay.value = deviceId;
        
        copyDeviceIdBtn.addEventListener('click', function() {
            deviceIdDisplay.select();
            document.execCommand('copy');
            
            const originalText = this.textContent;
            this.textContent = 'تم النسخ!';
            
            setTimeout(() => {
                this.textContent = originalText;
            }, 2000);
        });
        
        if (activationStatus.isActivated) {
            activateBtn.classList.add('activated');
            activateBtn.textContent = 'تم التفعيل';
        } else {
            // Show remaining days or hours based on what's more appropriate
            if (activationStatus.hoursRemaining < 24) {
                trialDaysRemaining.textContent = `${activationStatus.hoursRemaining} ساعة`;
            } else {
                trialDaysRemaining.textContent = activationStatus.daysRemaining;
            }
            
            if (activationStatus.needsActivation) {
                trialDaysRemaining.textContent = '0';
                trialDaysRemaining.classList.add('trial-expired');
            }
        }
    });
    
    activateBtn.addEventListener('click', function() {
        activationModal.style.display = 'block';
    });
    
    closeBtn.addEventListener('click', function() {
        activationModal.style.display = 'none';
    });
    
    if (activationStatus && activationStatus.needsActivation && !activationStatus.isActivated) {
        setTimeout(() => {
            activationModal.style.display = 'block';
        }, 1000);
    }
}

// Handle activation form submission with enabling functionality
const activationForm = document.getElementById('activationForm');
activationForm.addEventListener('submit', function(e) {
    e.preventDefault();
    const code = document.getElementById('activationCode').value.trim();
    
    import('./activation.js').then(({ activateApp }) => {
        if (activateApp(code)) {
            alert('تم تفعيل التطبيق بنجاح!');
            activationStatus.isActivated = true;
            const activateBtn = document.getElementById('activateAppBtn');
            activateBtn.classList.add('activated');
            activateBtn.textContent = 'تم التفعيل';
            const activationModal = document.getElementById('activationModal');
            activationModal.style.display = 'none';
            
            document.querySelectorAll('.tab-btn, input, select, button').forEach(el => {
                el.disabled = false;
                el.style.opacity = '1';
                el.style.cursor = '';
            });
            
            const messageOverlay = document.querySelector('.trial-expired-overlay');
            if (messageOverlay) {
                messageOverlay.remove();
            }
            
            location.reload();
        } else {
            alert('رقم التفعيل غير صحيح. يرجى المحاولة مرة أخرى.');
        }
    });
});

// Disable app functionality if trial expired
function disableAppIfTrialExpired() {
    if (activationStatus && activationStatus.trialExpired && !activationStatus.isActivated) {
        document.querySelectorAll('.tab-btn, button:not(#activateAppBtn):not(.copy-btn):not(#whatsappContactBtn)').forEach(btn => {
            btn.disabled = true;
            btn.style.opacity = '0.6';
            btn.style.cursor = 'not-allowed';
        });
        
        document.querySelectorAll('form').forEach(form => {
            if (form.id !== 'activationForm') {
                const inputs = form.querySelectorAll('input, select, button');
                inputs.forEach(input => {
                    input.disabled = true;
                    input.style.opacity = '0.6';
                    input.style.cursor = 'not-allowed';
                });
                form.style.opacity = '0.6';
            }
        });
        
        const messageOverlay = document.createElement('div');
        messageOverlay.className = 'trial-expired-overlay';
        messageOverlay.innerHTML = '<div class="trial-expired-message">انتهت الفترة التجريبية. يرجى تفعيل التطبيق للاستمرار.</div>';
        document.querySelector('.container').appendChild(messageOverlay);
        
        messageOverlay.addEventListener('click', () => {
            document.getElementById('activationModal').style.display = 'block';
        });
        
        // Force activation modal to open and prevent closing
        document.getElementById('activationModal').style.display = 'block';
        document.querySelector('#activationModal .close').style.display = 'none';
        
        // Intercept any clicks on the modal backdrop to prevent closing
        document.getElementById('activationModal').addEventListener('click', function(e) {
            if (e.target === this) {
                e.stopPropagation();
            }
        });
    }
}

// Add download customer report function
function downloadCustomerReport(customerId) {
    const customer = customers.find(c => c.id === customerId);
    if (!customer) return;
    
    // Show save as modal instead of directly downloading
    showSaveAsModal(customer);
}

// Show save as modal
function showSaveAsModal(customer) {
    const saveAsModal = document.getElementById('saveAsModal');
    const saveFileName = document.getElementById('saveFileName');
    
    // Set default filename
    saveFileName.value = `${customer.name}.html`;
    
    saveAsModal.style.display = 'block';
    
    // Store customer data for later use
    saveAsModal.dataset.customerId = customer.id;
}

// Generate and save report with custom filename
function generateAndSaveReport(customerId, filename) {
    const customer = customers.find(c => c.id === customerId);
    if (!customer) return;
    
    // Create HTML content for report
    let html = `
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>تقرير ${customer.name}</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                margin: 0;
                padding: 20px;
                background-color: #f8fafc;
            }
            .report-header {
                text-align: center;
                margin-bottom: 20px;
                padding: 20px;
                background: linear-gradient(135deg, #4a6fa5, #334e68);
                color: white;
                border-radius: 10px;
            }
            .customer-info {
                background-color: #f0f4f8;
                padding: 15px;
                border-radius: 8px;
                margin-bottom: 20px;
                border: 1px solid #cbd5e0;
            }
            table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 20px;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
                border: 2px solid #4a6fa5;
                border-radius: 8px;
                overflow: hidden;
            }
            th, td {
                padding: 12px 15px;
                text-align: right;
                border: 1px solid #ddd;
            }
            th {
                background-color: #4a6fa5;
                color: white;
                font-weight: bold;
            }
            tr:nth-child(even) {
                background-color: #f9f9f9;
            }
            .credit {
                color: #2ecc71;
                font-weight: bold;
            }
            .debit {
                color: #e74c3c;
                font-weight: bold;
            }
            .footer {
                margin-top: 30px;
                text-align: center;
                font-size: 0.9em;
                color: #7f8c8d;
            }
        </style>
    </head>
    <body>
        <div class="report-header">
            <h1>تقرير معاملات ${customer.name}</h1>
            <p>تاريخ التقرير: ${new Date().toLocaleDateString('ar-EG')}</p>
        </div>
        
        <div class="customer-info">
            <h2>معلومات العميل</h2>
            <p>اسم العميل: ${customer.name}</p>
            <p>الرصيد الحالي: <span class="${customer.balance >= 0 ? 'credit' : 'debit'}">${formatCurrency(customer.balance)}</span></p>
            <p>عدد المعاملات: ${customer.transactions.length}</p>
        </div>
        
        <h2>سجل المعاملات</h2>
        <table>
            <thead>
                <tr>
                    <th>التاريخ</th>
                    <th>نوع المعاملة</th>
                    <th>المبلغ</th>
                    <th>الوصف</th>
                    <th>الرصيد قبل</th>
                    <th>الرصيد بعد</th>
                </tr>
            </thead>
            <tbody>
    `;
    
    // Sort transactions from latest to oldest
    const sortedTransactions = [...customer.transactions].sort((a, b) => 
        new Date(b.date) - new Date(a.date)
    );
    
    if (sortedTransactions.length === 0) {
        html += `<tr><td colspan="6" style="text-align:center">لا يوجد معاملات</td></tr>`;
    } else {
        sortedTransactions.forEach(transaction => {
            html += `
                <tr>
                    <td>${formatDate(transaction.date)}</td>
                    <td class="${transaction.type === 'credit' ? 'credit' : 'debit'}">
                        ${transaction.type === 'credit' ? 'إضافة' : 'خصم'}
                    </td>
                    <td>${formatCurrency(transaction.amount)}</td>
                    <td>${transaction.description || ''}</td>
                    <td class="${transaction.balanceBefore >= 0 ? 'credit' : 'debit'}">${formatCurrency(transaction.balanceBefore || 0)}</td>
                    <td class="${transaction.balanceAfter >= 0 ? 'credit' : 'debit'}">${formatCurrency(transaction.balanceAfter || 0)}</td>
                </tr>
            `;
        });
    }
    
    html += `
            </tbody>
        </table>
        
        <div class="footer">
            <p>تم إنشاء هذا التقرير بواسطة تطبيق إدارة الحسابات</p>
        </div>
    </body>
    </html>
    `;
    
    // Create blob and download with custom filename
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    // Show confirmation message
    alert('تم حفظ الملف بنجاح');
}

// معالجة الأحداث عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    // Initialize activation status first to ensure it's available
    import('./activation.js').then(({ checkActivation, getDeviceId }) => {
        activationStatus = checkActivation();
        
        // After activationStatus is set, we can call disableAppIfTrialExpired
        disableAppIfTrialExpired();
        
        const deviceId = getDeviceId();
        if (document.getElementById('deviceIdDisplay')) {
            document.getElementById('deviceIdDisplay').value = deviceId;
        }
        
        const scriptExcel = document.createElement('script');
        scriptExcel.src = 'excel-utils.js';
        scriptExcel.type = 'module';
        document.head.appendChild(scriptExcel);
        
        setupActivationSystem();
        
        document.getElementById('whatsappContactBtn').addEventListener('click', function() {
            const numberElement = document.getElementById('whatsappNumber');
            if (numberElement.style.display === 'none') {
                numberElement.style.display = 'block';
            } else {
                numberElement.style.display = 'none';
            }
        });
        
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
                
                this.classList.add('active');
                document.getElementById(this.dataset.tab).classList.add('active');
                
                document.querySelector('.tabs').style.display = 'none';
                document.querySelectorAll('.go-back-btn').forEach(backBtn => {
                    backBtn.style.display = 'inline-flex';
                });
            });
        });
        
        document.querySelectorAll('.go-back-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
                document.querySelector('.tabs').style.display = 'flex';
                document.querySelectorAll('.go-back-btn').forEach(backBtn => {
                    backBtn.style.display = 'none';
                });
            });
        });
        
        updateCustomerSelect();
        displayCustomers();
        
        document.getElementById('newCustomerForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const name = document.getElementById('customerName').value.trim();
            
            if (name) {
                if (addCustomer(name, 0)) {
                    this.reset();
                }
            }
        });
        
        document.getElementById('transactionForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const customerId = document.getElementById('customerSelect').value;
            const type = document.getElementById('transactionType').value;
            const amount = document.getElementById('transactionAmount').value;
            const description = document.getElementById('transactionDescription').value.trim();
            
            if (customerId && type && amount && parseFloat(amount) > 0) {
                if (addTransaction(customerId, type, amount, description)) {
                    this.reset();
                    document.getElementById('customerSelect').value = '';
                }
            }
        });
        
        document.getElementById('searchCustomer').addEventListener('input', function() {
            const searchTerm = this.value.trim().toLowerCase();
            
            if (searchTerm === '') {
                displayCustomers();
            } else {
                const filteredCustomers = customers.filter(customer => 
                    customer.name.toLowerCase().includes(searchTerm)
                );
                displayCustomers(filteredCustomers);
            }
        });
        
        document.getElementById('deleteCustomerBtn').addEventListener('click', function() {
            if (confirm('هل أنت متأكد من أنك تريد حذف العميل وجميع معاملاته؟')) {
                const customerId = this.dataset.id;
                deleteCustomer(customerId);
                document.getElementById('customerDetails').style.display = 'none';
            }
        });
        
        document.getElementById('deleteTransactionsBtn').addEventListener('click', function() {
            if (confirm('هل أنت متأكد من أنك تريد حذف معاملات العميل فقط؟')) {
                const customerId = document.getElementById('deleteCustomerBtn').dataset.id;
                deleteCustomerTransactions(customerId);
                document.getElementById('customerDetails').style.display = 'none';
            }
        });
        
        document.querySelector('.close').addEventListener('click', () => {
            document.getElementById('customerDetails').style.display = 'none';
        });
        
        window.addEventListener('click', (e) => {
            const modal = document.getElementById('customerDetails');
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        });
        
        document.getElementById('exportBtn')?.addEventListener('click', async function() {
            if (!activationStatus.isActivated) {
                alert('هذه الميزة متاحة فقط في النسخة المدفوعة. يرجى تفعيل التطبيق للوصول إلى جميع الميزات.');
                const activationModal = document.getElementById('activationModal');
                activationModal.style.display = 'block';
                return;
            }
            
            try {
                exportDatabase();
            } catch (error) {
                console.error('Export error:', error);
                alert('حدث خطأ أثناء تصدير البيانات: ' + error.message);
            }
        });
        
        document.getElementById('importBtn')?.addEventListener('click', function() {
            if (!activationStatus.isActivated) {
                alert('هذه الميزة متاحة فقط في النسخة المدفوعة. يرجى تفعيل التطبيق للوصول إلى جميع الميزات.');
                const activationModal = document.getElementById('activationModal');
                activationModal.style.display = 'block';
                return;
            }
            
            document.getElementById('importFile').click();
        });
        
        document.getElementById('importFile')?.addEventListener('change', async function(e) {
            if (!this.files || !this.files.length) return;
            
            try {
                const file = this.files[0];
                importDatabase(file);
            } catch (error) {
                console.error('Import error:', error);
                alert('حدث خطأ أثناء استيراد البيانات: ' + error.message);
            }
            
            this.value = '';
        });
        
        document.getElementById('addCustomerTransactionBtn').addEventListener('click', function() {
            const customerId = this.dataset.id;
            
            let modalTransactionForm = document.getElementById('modalTransactionForm');
            
            if (!modalTransactionForm) {
                modalTransactionForm = document.createElement('form');
                modalTransactionForm.id = 'modalTransactionForm';
                modalTransactionForm.className = 'edit-transaction-form';
                
                modalTransactionForm.innerHTML = `
                    <div class="form-group">
                        <label for="modalTransactionType">نوع المعاملة:</label>
                        <select id="modalTransactionType" required>
                            <option value="credit">إضافة</option>
                            <option value="debit">خصم</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="modalTransactionAmount">المبلغ:</label>
                        <input type="number" id="modalTransactionAmount" required min="0.01" step="0.01">
                    </div>
                    <div class="form-group">
                        <label for="modalTransactionDescription">الوصف:</label>
                        <input type="text" id="modalTransactionDescription">
                    </div>
                    <div class="form-actions">
                        <button type="button" class="btn cancel-btn" id="cancelModalTransaction">إلغاء</button>
                        <button type="submit" class="btn">تسجيل المعاملة</button>
                    </div>
                `;
                
                document.getElementById('transactionsTable').parentNode.insertBefore(
                    modalTransactionForm, 
                    document.getElementById('transactionsTable')
                );
                
                document.getElementById('cancelModalTransaction').addEventListener('click', function() {
                    modalTransactionForm.style.display = 'none';
                });
                
                modalTransactionForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    
                    const type = document.getElementById('modalTransactionType').value;
                    const amount = document.getElementById('modalTransactionAmount').value;
                    const description = document.getElementById('modalTransactionDescription').value.trim();
                    
                    const currentCustomerId = document.getElementById('addCustomerTransactionBtn').dataset.id;
                    
                    if (amount && parseFloat(amount) > 0) {
                        if (addTransaction(currentCustomerId, type, amount, description)) {
                            this.reset();
                            this.style.display = 'none';
                            
                            viewCustomerDetails(currentCustomerId);
                        }
                    }
                });
            } else {
                modalTransactionForm.style.display = 'block';
            }
            
            document.getElementById('modalTransactionAmount').focus();
        });
        
        document.body.addEventListener('click', function(e) {
            if (e.target && e.target.classList.contains('download-customer-report-btn')) {
                const customerId = e.target.dataset.id;
                downloadCustomerReport(customerId);
            }
        });
        
        // Setup save as modal event handlers
        const saveAsModal = document.getElementById('saveAsModal');
        const saveAsModalClose = document.getElementById('saveAsModalClose');
        const cancelSave = document.getElementById('cancelSave');
        const confirmSave = document.getElementById('confirmSave');
        
        saveAsModalClose.addEventListener('click', function() {
            saveAsModal.style.display = 'none';
        });
        
        cancelSave.addEventListener('click', function() {
            saveAsModal.style.display = 'none';
        });
        
        confirmSave.addEventListener('click', function() {
            const customerId = saveAsModal.dataset.customerId;
            const filename = document.getElementById('saveFileName').value.trim();
            
            if (!filename) {
                alert('يرجى إدخال اسم الملف');
                return;
            }
            
            // Ensure .html extension
            const finalFilename = filename.endsWith('.html') ? filename : filename + '.html';
            
            generateAndSaveReport(customerId, finalFilename);
            saveAsModal.style.display = 'none';
        });
        
        // Close modal when clicking outside
        window.addEventListener('click', function(e) {
            if (e.target === saveAsModal) {
                saveAsModal.style.display = 'none';
            }
        });
    });
});

// Helper: generate flat transaction report array for all customers
function generateTransactionReportRows() {
    const rows = [];
    customers.forEach(customer => {
        customer.transactions.forEach(transaction => {
            rows.push({
                customerName: customer.name,
                date: transaction.date,
                type: transaction.type,
                amount: transaction.amount,
                description: transaction.description || "",
                balanceBefore: transaction.balanceBefore,
                balanceAfter: transaction.balanceAfter
            });
        });
    });
    // Sort from latest to oldest
    return rows.sort((a, b) => new Date(b.date) - new Date(a.date));
}

// Download report as Excel file (local file)
async function downloadReportAsExcel(rows, filename) {
    const xlsxCdn = "https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js";
    
    // Lazy load XLSX if needed
    async function loadXLSX() {
        if (window.XLSX) return window.XLSX;
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = xlsxCdn;
            script.onload = () => resolve(window.XLSX);
            script.onerror = () => reject(new Error('تعذر تحميل مكتبة إكسيل'));
            document.head.appendChild(script);
        });
    }
    
    try {
        if (!activationStatus.isActivated) {
            alert('هذه الميزة متاحة فقط في النسخة المدفوعة. يرجى تفعيل التطبيق للوصول إلى جميع الميزات.');
            const activationModal = document.getElementById('activationModal');
            activationModal.style.display = 'block';
            return;
        }
        
        const XLSX = await loadXLSX();
        const ws = XLSX.utils.json_to_sheet(rows);
        
        // Create workbook and append
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'تقرير-المعاملات');
        
        // Save file locally with name
        XLSX.writeFile(wb, filename);
    } catch (err) {
        alert('حدث خطأ أثناء تحميل ملف التقرير: ' + err.message);
    }
}