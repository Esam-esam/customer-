// Activation system for the accounting app

// Check if the app needs activation
function checkActivation() {
    // Get installation date or set it if not exists
    let installDate = localStorage.getItem('installDate');
    if (!installDate) {
        installDate = new Date().toISOString();
        localStorage.setItem('installDate', installDate);
    }
    
    // Generate device ID if not exists
    if (!localStorage.getItem('deviceId')) {
        const deviceId = generateDeviceId();
        localStorage.setItem('deviceId', deviceId);
    }
    
    // Check if app is already activated
    const isActivated = localStorage.getItem('isActivated') === 'true';
    if (isActivated) {
        return { needsActivation: false, isActivated: true };
    }
    
    // Calculate hours since installation (changed from days)
    const installDateObj = new Date(installDate);
    const currentDate = new Date();
    const timeDiff = currentDate.getTime() - installDateObj.getTime();
    const hoursSinceInstall = Math.floor(timeDiff / (1000 * 60 * 60));
    const daysSinceInstall = Math.floor(hoursSinceInstall / 24);
    
    // Need activation if more than 48 hours (2 days)
    return {
        needsActivation: hoursSinceInstall > 48,
        isActivated: false,
        daysSinceInstall: daysSinceInstall,
        hoursSinceInstall: hoursSinceInstall,
        daysRemaining: Math.max(0, 2 - daysSinceInstall),
        hoursRemaining: Math.max(0, 48 - hoursSinceInstall),
        trialExpired: hoursSinceInstall > 48
    };
}

// Generate a unique device ID based on installation time
function generateDeviceId() {
    const date = new Date();
    const seconds = date.getSeconds();
    const minutes = date.getMinutes();
    const hours = date.getHours();
    const day = date.getDate();
    const month = date.getMonth() + 1;
    const year = date.getFullYear();
    
    // Ensure we don't get 0 with multiplication
    if (seconds === 0 || minutes === 0 || hours === 0 || day === 0 || month === 0) {
        return ((seconds + 1) * (minutes + 1) * (hours + 1) * (day + 1) * (month + 1) * year * 7).toString();
    }
    
    // Multiply all components by 7
    return (seconds * minutes * hours * day * month * year * 7).toString();
}

// Get the stored device ID
function getDeviceId() {
    return localStorage.getItem('deviceId') || generateDeviceId();
}

// Calculate the activation code based on device ID
function calculateActivationCode(deviceId) {
    return ((parseInt(deviceId) + 1981) * 7).toString();
}

// Verify activation code
function verifyActivationCode(code) {
    const deviceId = getDeviceId();
    const expectedCode = calculateActivationCode(deviceId);
    return code === expectedCode;
}

// Activate the application
function activateApp(code) {
    if (verifyActivationCode(code)) {
        localStorage.setItem('isActivated', 'true');
        return true;
    }
    return false;
}

export { checkActivation, getDeviceId, calculateActivationCode, verifyActivationCode, activateApp };